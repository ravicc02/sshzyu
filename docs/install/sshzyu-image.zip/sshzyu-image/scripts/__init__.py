"""SSHZYU image skill scripts."""
