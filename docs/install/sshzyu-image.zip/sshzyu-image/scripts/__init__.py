"""SSHZYU image skill scripts."""
