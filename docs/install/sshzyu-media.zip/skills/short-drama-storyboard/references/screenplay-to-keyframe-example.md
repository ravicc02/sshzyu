# 完整示例：从剧本片段拆出分镜与首帧提示词

前情：沈禾（提示词名称 `Shenhe`）的弟弟穿深蓝汽修工装去社区洗衣房送洗衣服后失联；老板蒋姨（提示词名称 `Jiangyi`）一口咬定他放下衣服就从前门走了，可沈禾刚在后巷排水沟边捡到了那枚 17 号塑料取衣牌，牌背防滑胶槽里还粘着一小撮带干涸血迹的深蓝工装线头。

## 剧本片段与拆镜对照

~~~md
## EP004-SC002 内 · 社区洗衣房 · 清晨

滚筒烘干机还在嗡嗡转动。沈禾把写着“17”的塑料取衣牌攥在手心，隔着柜台盯住蒋姨，迟迟没递过去。

蒋姨：衣服昨晚就烘干了，你今天来，不是取衣服的吧。

[SFX] 烘干机咔哒一声停转。

沈禾当着她的面摊开右掌。取衣牌背面粘着一小片带干涸血迹的蓝线头。
~~~

| 剧本段落 | 对应镜头 | 拆镜考虑 |
|---|---|---|
| 场头对峙 + 攥牌不递 + 蒋姨开口点破 | SHOT-EP004-001 | 借沈禾抵住柜台的动作顺带交代木柜台、转动的烘干机与两人隔台关系，同一交锋回合一镜演完 |
| `[SFX]` 烘干机骤停 + 当面摊开右掌 | SHOT-EP004-002 | 机器骤停衬出全场死寂，镜头随视线落向摊平的右掌 |
| 牌背粘着带干涸血迹的蓝线头 | SHOT-EP004-003 | 切手部与证物近特写坐实牌背血迹线头，后景虚焦保留蒋姨盯住证物的反应 |

## 前两镜调度拆解节选

前两镜节选来源、时长、起止与声音拆法（正式落入《分镜.md》时每镜均须补齐 `输入参考图`、`出场设定` 与 `### 首帧提示词`，完整单镜格式见下节 `SHOT-EP004-003`）：

~~~~markdown
## SHOT-EP004-001 · 攥牌隔台对峙

- 来源：EP004-SC002「沈禾把写着“17”的塑料取衣牌攥在手心，隔着柜台盯住蒋姨，迟迟没递过去。」及蒋姨台词
- 时长：4s
- 目的：立住蒋姨守在柜台内、沈禾攥死证物的紧绷对峙，一句台词挑破来者不善。
- 景别/机位：竖屏双人中景，平视，机位在靠街玻璃门侧，木柜台横沿切分画面。
- 运镜：固定。
- 起点：沈禾站柜台外侧（画左）右拳攥紧取衣牌，蒋姨站柜台内侧（画右），后墙滚筒烘干机嗡嗡转动。
- 动作：沈禾把右拳抵上木柜台沿按住不动；蒋姨双手搭台面未伸手去接，开口点破她今天来不是为了取衣服。
- 终点：两人隔台僵持未动，沈禾右拳仍紧攥在台沿。
- 声音：滚筒烘干机低沉嗡鸣垫底；蒋姨平静试探的现场对白。

## SHOT-EP004-002 · 停机死寂中摊掌

- 来源：EP004-SC002「[SFX] 烘干机咔哒一声停转。沈禾当着她的面摊开右掌。」
- 时长：3s
- 目的：借机器骤停放大沉默，把视线焦点从两人脸上引向沈禾摊开的右掌。
- 景别/机位：竖屏双人中近景，平视。
- 运镜：随沈禾摊掌动作轻微下摇收近，终点框住柜台上的右掌与柜台后蒋姨垂落的视线。
- 起点：承接 SHOT-EP004-001 收尾，沈禾右拳抵在木柜台沿，蒋姨隔台注视她。
- 动作：烘干机咔哒停转，室内骤静；沈禾目光不移，当着蒋姨的面慢慢摊平右掌。
- 终点：右掌心朝上摊平，塑料取衣牌正面贴掌心、背面朝上露出。
- 声音：[SFX] 滚筒烘干机咔哒停转，随后室内一片死寂，无对白。
~~~~

## `SHOT-EP004-003` 完整单镜与首帧提示词示范

磁盘尚未放入实拍参考图时，`输入参考图` 用 `PLAN-...` 预留图位指向本镜首帧或对应设定图（已有实图时改绑 `REF-...`；尚无对应设定图条目时 `图片提示词项` 可写 `无` 或省略），首帧提示词按 `short-drama.json#/format/prompt_language`（本例为 `en`）输出：

~~~~markdown
## SHOT-EP004-003 · 牌背血线头特写

- 来源：EP004-SC002「取衣牌背面粘着一小片带干涸血迹的蓝线头。」
- 时长：2s
- 目的：让观众看清取衣牌背面的深蓝工装线头与干涸血迹，同时保住后景蒋姨盯住证物的空间关系。
- 景别/机位：手部与证物近特写，略俯视，后景浅景深带到柜台内侧。
- 运镜：固定。
- 起点：沈禾右掌心朝上稳稳托着背面朝上的塑料取衣牌，后景虚焦处蒋姨低头盯住她掌心。
- 动作：右掌托牌纹丝不动，后景蒋姨目光死死钉在牌背蓝线头上。
- 终点：保持同一托牌特写姿态定格（写有“17”的牌正面贴在掌心不可见）。
- 图片提示词项：IMG-SHENHE-SHEET《沈禾角色设定图》（控制：右手肤色、深色夹克袖口）；IMG-CLAIM-TAG《取衣牌道具设定图》（控制：塑料牌轮廓、背面防滑胶槽、边缘旧磨损）；IMG-LAUNDRY-ROOM《社区洗衣房场景板》（控制：旧木柜台台面、后墙滚筒烘干机、清晨冷白顶光）。
- 输入参考图：PLAN-START（顺序：1）· SHOT-EP004-003《本镜首帧》（用途：起始帧；控制：手部托牌特写构图、后景视线关系；不得控制：镜头运动）；PLAN-TAG（顺序：2）· IMG-CLAIM-TAG《取衣牌道具设定图》（用途：造型状态；控制：牌背防滑胶槽、带干涸血迹的深蓝线头；不得控制：手部姿态、背景光线）。
- 出场设定：《视觉设定.md》·人物「沈禾」（控制：右手特征、袖口）；人物「蒋姨」（控制：后景外貌轮廓、低垂视线）；道具「取衣牌」（控制：牌身轮廓、背面防滑槽、带血蓝线头位置）；地点「社区洗衣房」（控制：木柜台外沿、停转烘干机、冷白顶光）。
- 声音：清晨店铺微弱底噪，无对白。

### 首帧提示词
> 9:16 vertical extreme close-up, 85mm macro-style shallow depth of field at counter height, slight high angle. Over the worn wooden counter edge of a community laundry room, Shenhe holds her right palm flat and steady facing up in the sharp foreground focus; a rectangular aged plastic claim tag lies back-side up across her palm, a tiny tuft of dark-blue cotton workwear thread stained with dried dark-red blood caught in the anti-slip rubber groove on the back of the tag. Across the wooden counter in the softly blurred background, Jiangyi stands still behind the counter with her lowered gaze fixed onto the tag in Shenhe's palm, a row of stationary drum dryers dimly visible against the back wall. Even cool-white morning overhead fluorescent light, realistic Chinese motion-comic keyframe, the numbered front face of the tag hidden against the palm, no flipping motion, no text, no watermark.
~~~~

## 跨镜连戏接力核对

| 连戏维度 | `SHOT-EP004-001` 终点 | `SHOT-EP004-002` 起点 → 终点 | `SHOT-EP004-003` 起点 |
|---|---|---|---|
| 沈禾右手与取衣牌 | 握拳抵住柜台沿，取衣牌藏在拳心 | 握拳 → 掌心朝上摊平，牌背朝上露出 | 掌心朝上托牌静止，牌背血线头特写清晰 |
| 蒋姨视线 | 隔台平视沈禾脸部 | 从沈禾脸部垂落向她摊开的右掌 | 死死钉在掌心牌背上 |
| 后墙烘干机 | 嗡嗡运转 | 咔哒一声停转 | 保持静止停转 |
